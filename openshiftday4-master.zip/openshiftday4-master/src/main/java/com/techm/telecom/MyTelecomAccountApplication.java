package com.techm.telecom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyTelecomAccountApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyTelecomAccountApplication.class, args);
	}

}
